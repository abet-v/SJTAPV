/*
** my_putchar.c for libmy in /home/aslafy_z/rendu/Piscine-C-lib
** 
** Made by Zadkiel Aslafy Aharonian
** Login   <aslafy_z@epitech.net>
** 
** Started on  Tue Oct  8 09:34:08 2013 Zadkiel Aslafy Aharonian
** Last update Tue Oct  8 09:34:43 2013 Zadkiel Aslafy Aharonian
*/

int	my_putchar(char c)
{
  write(1, &c, 1);
}
