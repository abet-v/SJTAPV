/*
** my_square_root.c for libmy in /home/aslafy_z/rendu/Piscine-C-lib
** 
** Made by Zadkiel Aslafy Aharonian
** Login   <aslafy_z@epitech.net>
** 
** Started on  Tue Oct  8 09:35:16 2013 Zadkiel Aslafy Aharonian
** Last update Tue Oct  8 09:42:42 2013 Zadkiel Aslafy Aharonian
*/

int	my_square_root(int nb)
{
}
