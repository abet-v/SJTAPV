/*
** my_showstr.c for libmy in /home/aslafy_z/rendu/Piscine-C-lib
** 
** Made by Zadkiel Aslafy Aharonian
** Login   <aslafy_z@epitech.net>
** 
** Started on  Tue Oct  8 09:38:23 2013 Zadkiel Aslafy Aharonian
** Last update Tue Oct  8 09:38:58 2013 Zadkiel Aslafy Aharonian
*/

int	my_showstr(char *str)
{

}
