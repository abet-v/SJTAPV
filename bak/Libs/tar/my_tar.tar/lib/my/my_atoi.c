/*
** my_atoi.c for lib in /home/aslafy_z/rendu/Bistro
**
** Made by Zadkiel Aslafy Aharonian
** Login   <aslafy_z@epitech.net>
**
** Started on  Sat Nov  2 21:26:41 2013 Zadkiel Aslafy Aharonian
** Last update Sat Nov  2 21:28:36 2013 Zadkiel Aslafy Aharonian
*/

#include "my.h"

int	my_atoi(char *str)
{
  return (my_getnbr(str));
}
