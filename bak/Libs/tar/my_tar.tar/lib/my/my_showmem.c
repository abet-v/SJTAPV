/*
** my_showmem.c for libmy in /home/aslafy_z/rendu/Piscine-C-lib
** 
** Made by Zadkiel Aslafy Aharonian
** Login   <aslafy_z@epitech.net>
** 
** Started on  Tue Oct  8 09:39:21 2013 Zadkiel Aslafy Aharonian
** Last update Tue Oct  8 09:39:38 2013 Zadkiel Aslafy Aharonian
*/

int	my_showmem(char *str, int size)
{
}
